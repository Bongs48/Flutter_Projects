package com.example.to_do_lists

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
