import 'package:flutter/material.dart';
import 'package:to_do_lists/main.dart';
import 'package:to_do_lists/pages/display.dart';
import 'package:to_do_lists/utils/todo_Tiles.dart';




class HomePage extends StatelessWidget {
  List toDoList =[

    ["Wash the car",false],
    ["Go to store",false],
  ["Make something to eat",false]
  ];


  //checkbox was checkecked
     HomePage({Key? key}) : super(key: key);

   void checkBoxChanged(bool? value, int index){
  //    setState((){
  //
  //   }
  //   );
   }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
backgroundColor: Colors.amberAccent,

      appBar: AppBar(
        title: Text('To Do'),
        elevation: 0,
      ),
      body:ListView.builder(
itemCount: toDoList.length,
        itemBuilder: (context, index){
return ToDoTile(
    taskName: toDoList[index][0],
    taskCompleted: toDoList[index][1],
    onChanged:(value) => checkBoxChanged(value,index),
);

        },
      ) ,
        floatingActionButton: FloatingActionButton(
        onPressed: (){
    Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => const Display()
    )
    );

    }));
  }

}