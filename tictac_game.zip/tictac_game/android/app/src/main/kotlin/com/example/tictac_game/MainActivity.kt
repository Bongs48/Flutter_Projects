package com.example.tictac_game

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
